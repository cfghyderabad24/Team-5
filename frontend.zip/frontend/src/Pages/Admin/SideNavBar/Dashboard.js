import React, { useState } from 'react';
import { LayoutDashboard,Bell,Ticket,CircleUser,ScanBarcode,ReceiptIndianRupee,UserPlus,UserMinus,BadgePlus, User,StickyNote,Files,Settings,History} from "lucide-react";
import { Sidebar, SidebarItem } from "./Sidebar";
const Dashboard = () => {
  
  return (
    <div>
      <div>
      <Sidebar>
      <SidebarItem
              icon={<LayoutDashboard size={20} />}
              text="Dashboard"
              to=""
              active
       />

            {/* <SidebarItem
              icon={<User size={20}/>}
              text="Clients"
              dropdownItems={[
                { text: "Add Clients", icon:<UserPlus />,to: "add-client" },
                { text: "View Clients", icon:<UserMinus />, to: "view-client" },
                { text: "Add Company", icon:<UserMinus />, to: "addcompany" }
                // { text: "View Clients", icon:<UserMinus />, to: "view-client" }
              ]}
            /> */}
        {/* <SidebarItem
              icon={<Bell size={20} />}
              text="Notification"
              to="notificationsa"
              
       />  */}
         {/* <SidebarItem
              icon={<Ticket  size={20} />}
              text="Support Ticket"
              to="support-ticketa"
              
          /> */}
          {/* <SidebarItem
              icon={<ReceiptIndianRupee size={20}/>}
              text="Invoices"
              dropdownItems={[
                { text: "Create Invoice", to: "createinvoice" },
                { text: "Invoice History", to: "viewbills" },
                // { text: "GST Notice", to: "gstnoticea" },
                
              ]}
            /> */}
          {/* <SidebarItem
              icon={<ScanBarcode size={20}/>}
              text="Transactions"
              dropdownItems={[
                // { text: "Bills", to: "bills" },
                { text: "Transaction History", to: "transactionhistory" },
                { text: "Transaction Status", to: "transactionstatus" },
                // { text: "GST Notice", to: "gstnoticea" },
                
              ]}
            /> */}
             {/* <SidebarItem
              icon={<History size={20} />}
              text="History"
              to="historya"
            /> */}

        {/* <SidebarItem
              
              text="Add On Services"
              to="AddOnServices"
              icon={<BadgePlus size={20}/>}
              
              />  */}
            {/* <SidebarItem
              icon={<Settings size={20}/>}
              text="Settings"
              dropdownItems={[
                // { text: "Banner Settings", to: "banner-settings" },
                // { text: "Whatsapp Settings", to: "whatsapp-settings" },
                { text: "Email Settings", to: "email-settings" },
                { text: "Payment Settings", to: "payment-settings" },
                { text: "Banner Settings", to: "banner-settings" },
                { text: "IT Returns Settings", to: "itreturns-settings" },
                { text: "GST Returns Settings", to: "gstreturns-settings" },
                { text: "GST Notice Settings", to: "gstnotice-settings" },
                { text: "Company Settings", to: "company-settings" },
                { text: "CMA Preparation Settings", to: "cma-settings" },
                { text: "ROC Filings", to: "roc-settings" },
                { text: "License Settings", to: "license-settings" },
                { text: "Add On Services Settings", to: "addonservicessettings" },
                // { text: "Others", to: "othersa" },
              ]}
            /> */}
      </Sidebar>
      </div>
  </div>
  );
};

export default Dashboard;