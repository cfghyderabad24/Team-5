import React from 'react'
import Registration from '../../../Components/Admin/Registration'
import NavigationBar from '../NavigationBar/NavigationBar'

function AddEmployee() {
  return (
    <div>
      <NavigationBar/>
        <Registration/>
    </div>
  )
}

export default AddEmployee