import React from 'react'
import NavigationBar from '../NavigationBar/NavigationBar'

function AddClient() {
  return (
    <div>
      <NavigationBar/>
    </div>
  )
}

export default AddClient