function SampleApp(){
    return "Hello";
}
export default SampleApp;